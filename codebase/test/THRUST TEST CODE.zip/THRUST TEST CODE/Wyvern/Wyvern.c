// -------------------------------
// Wyvern Quadrotor
// On-Board Software
// version: 1.0.2
// date: April 10, 2010
// authors: William Etter, Paul Martin, Uriah Baalke
// -------------------------------

// DEFINES

// INCLUDES
#include "wyvern.h"
#include "uart.h"
#include "pwm.h"
#include "wyvern-rf.h"
#include "adc.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// CONSTANT VARIABLES

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// GLOBAL VARIABLES
// RF Variables
char local[5] = {0x77, 0x79, 0x76, 0x30, 0x30}; // Wyvern Quadrotor Wyv00
char contr[5] = {0x63, 0x6F, 0x6E, 0x74, 0x72}; // Wyvern Controller
packet_com_t incoming;
packet_inf_t outgoing;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// FUNCTION HEADERS
void init_wyvern(void);

// ===========================================================

/*************************************************************************
Interrupt Subroutines (ISRs)
**************************************************************************/

ISR(PCINT0_vect)
{
	if(!check(PINB,4)){ // change was high-to-low
		// a wireless packet was received
		RFreceive((char*) &incoming);
		//TransmitString("packet received: ");
		LED_ucred_toggle();
	}
}


/*************************************************************************
Function: main()
**************************************************************************/
int main(void)
{
	init_wyvern();
	int duty = 1000;
	char input;
	char dutystring[8];
	LED_ucgreen_on();
	for(;;){
		
		TransmitString("Duty = ");
		itoa(duty,dutystring,10);
		TransmitString(dutystring);
		TransmitString("\n\r");
		input = ReceiveByte();
		set(PORTE,6);
		if(input == 'u'){
			if(duty<=1998)
				duty+=2;
		}
		else if(input == 'd'){
			if(duty>=1002)
				duty-=2;
		}
		else if(input == '='){
			if(duty<=1898)
				duty+=100;
		}
		else if(input == '-'){
			if(duty>=1102)
				duty-=100;
		}
		else if(input == '1'){
			duty=1480;
		}
		else if(input == '2'){
			duty=1300;
		}
		else if(input == '3'){
			duty=1200;
		}
		else if(input == 's'){
			duty=1106;
		}
		else if(input == ' '){
			duty = 1000;
			clear(PORTE,6);
		}
		set_duty(1,duty);
		toggle(PORTE,2);
	}
	return 0;
}

/*************************************************************************
Function: init_wyvern()
Purpose:  Runs all initialization functions
		  Enables interrupts
Input:    None
Returns:  None
**************************************************************************/
void init_wyvern(void)
{
	// Setup Wyvern Systems
	init_uc();		//UC
	init_uart();	// Serial  Communication
	init_pwm();		// Motor PWM Control

	// Enable Global Interrupts
	sei();
}


